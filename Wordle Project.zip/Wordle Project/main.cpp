#include <iostream>
#include <list>
#include <algorithm>
#include <map>
#include <queue>
#include <random>
#include <time.h>
#include <iterator>
#include <set>
#include <stack>
using namespace std;


//Functions

string randomWord(list<string> l, int a) {
    srand(time(NULL));
    list<string>::iterator litr = l.begin();
    int random = rand() % l.size();
    advance(litr, random);
    return *litr;
}

//Swap unordered keyboard into ordered keyboard

stack<char> clearStack(stack<char> s) {
    while (!s.empty()) {
        s.pop();
    }
    return s;
}

queue<char> clearQueue(queue<char> q) {
    while (!q.empty()) {
        q.pop();
    }
    return q;
}

stack<char> swapKeyboard(queue<char> p, stack<char> o) {
    for (int count = 0; count < 26; count++) {
        o.push(p.front());
        p.pop();
    }
    return o;
}

void displayKeyboard(stack<char> o) {
    stack<char> f = o;
    while (!f.empty()) {
        cout << "\t";
        for (int count = 0; count < 10; count++) {
            cout << " " << f.top();
            f.pop();
        }
        cout << "\n\t ";
        for (int count = 0; count < 9; count++) {
            cout << " " << f.top();
            f.pop();
        }
        cout << "\n\t  ";
        for (int count = 0; count < 7; count++) {
            cout << " " << f.top();
            f.pop();
        }
    }
    cout << endl;

}

void displayLetters(map<char, int> a, set<char> l, int at, stack<char> o) {
    if (at > 0) {
        cout << "List of available letters:\n";
        stack<char> f = o;
        while (!f.empty()) {
            for (int count = 0; count < 10; count++) {
                cout << " " << f.top();
                f.pop();
            }
            cout << "\n ";
            for (int count = 0; count < 9; count++) {
                cout << " " << f.top();
                f.pop();
            }
            cout << "\n  ";
            for (int count = 0; count < 7; count++) {
                cout << " " << f.top();
                f.pop();
            }
        }
        cout << endl;
        set<int>::iterator sitr;
        if (l.empty() == true) {
            cout << endl;
        } else {
            cout << endl << "List of correct letters:\n\t";
            for (auto sitr = l.begin(); sitr != l.end(); ++sitr) {
                cout << *sitr << " ";
            }
            cout << endl << endl;
        }

    }
}

//Function to display the word progress

void displayProgress(multimap<int, char> q, string w, string a) {
    for (int count = 0; count < 5; count++) {
        multimap<int, char>::iterator mitr;
        mitr = q.find(count);
        if (mitr->second == w[count]) {
            cout << mitr->second << " ";
        } else {
            cout << "_ ";
        }
    }
    cout << endl;
}

void displayProgress4(multimap<int, char> q, string w, string a) {
    for (int count = 0; count < 4; count++) {
        multimap<int, char>::iterator mitr;
        mitr = q.find(count);
        if (mitr->second == w[count]) {
            cout << mitr->second << " ";
        } else {
            cout << "_ ";
        }
    }
    cout << endl;
}

void displayProgress6(multimap<int, char> q, string w, string a) {
    for (int count = 0; count < 6; count++) {
        multimap<int, char>::iterator mitr;
        mitr = q.find(count);
        if (mitr->second == w[count]) {
            cout << mitr->second << " ";
        } else {
            cout << "_ ";
        }
    }
    cout << endl;
}

multimap<int, char> storeProgress(multimap<int, char> q, string w, string a) {
    for (int count = 0; count < 5; count++) {
        if (w[count] == a[count]) {
            q.insert(pair<int, char>(count, w[count]));
        }
    }
    return q;
}

multimap<int, char> storeProgress4(multimap<int, char> q, string w, string a) {
    for (int count = 0; count < 4; count++) {
        if (w[count] == a[count]) {
            q.insert(pair<int, char>(count, w[count]));
        }
    }
    return q;
}

multimap<int, char> storeProgress6(multimap<int, char> q, string w, string a) {
    for (int count = 0; count < 6; count++) {
        if (w[count] == a[count]) {
            q.insert(pair<int, char>(count, w[count]));
        }
    }
    return q;
}

//Function to convert lowercase to uppercase letter

string lowerUpper(string a) {
    for (int count = 0; count < 5; count++)
        if (a[count] >= 'a' && a[count] <= 'z') {
            int ascii = a[count];
            ascii = ascii - 32;
            a[count] = ascii;
        }
    return a;
}

string lowerUpper4(string a) {
    for (int count = 0; count < 4; count++)
        if (a[count] >= 'a' && a[count] <= 'z') {
            int ascii = a[count];
            ascii = ascii - 32;
            a[count] = ascii;
        }
    return a;
}

string lowerUpper6(string a) {
    for (int count = 0; count < 6; count++)
        if (a[count] >= 'a' && a[count] <= 'z') {
            int ascii = a[count];
            ascii = ascii - 32;
            a[count] = ascii;
        }
    return a;
}

//Function to convert uppercase to lowercase letter

string upperLower(string a) {
    for (int count = 0; count < 5; count++)
        if (a[count] >= 'A' && a[count] <= 'Z') {
            int ascii = a[count];
            ascii = ascii + 32;
            a[count] = ascii;
        }
    return a;
}

string upperLower4(string a) {
    for (int count = 0; count < 4; count++)
        if (a[count] >= 'A' && a[count] <= 'Z') {
            int ascii = a[count];
            ascii = ascii + 32;
            a[count] = ascii;
        }
    return a;
}

string upperLower6(string a) {
    for (int count = 0; count < 6; count++)
        if (a[count] >= 'A' && a[count] <= 'Z') {
            int ascii = a[count];
            ascii = ascii + 32;
            a[count] = ascii;
        }
    return a;
}

queue<char> gatherKeyboard(queue<char> o, map<char, int> a) {
    map<char, int> ::iterator oitr;
    oitr = a.find('M');
    if (oitr->second == 1) {
        o.push('M');
    } else {
        o.push(' ');
    }
    oitr = a.find('N');
    if (oitr->second == 1) {
        o.push('N');
    } else {
        o.push(' ');
    }
    oitr = a.find('B');
    if (oitr->second == 1) {
        o.push('B');
    } else {
        o.push(' ');
    }
    oitr = a.find('V');
    if (oitr->second == 1) {
        o.push('V');
    } else {
        o.push(' ');
    }
    oitr = a.find('C');
    if (oitr->second == 1) {
        o.push('C');
    } else {
        o.push(' ');
    }
    oitr = a.find('X');
    if (oitr->second == 1) {
        o.push('X');
    } else {
        o.push(' ');
    }
    oitr = a.find('Z');
    if (oitr->second == 1) {
        o.push('Z');
    } else {
        o.push(' ');
    }
    oitr = a.find('L');
    if (oitr->second == 1) {
        o.push('L');
    } else {
        o.push(' ');
    }
    oitr = a.find('K');
    if (oitr->second == 1) {
        o.push('K');
    } else {
        o.push(' ');
    }
    oitr = a.find('J');
    if (oitr->second == 1) {
        o.push('J');
    } else {
        o.push(' ');
    }
    oitr = a.find('H');
    if (oitr->second == 1) {
        o.push('H');
    } else {
        o.push(' ');
    }
    oitr = a.find('G');
    if (oitr->second == 1) {
        o.push('G');
    } else {
        o.push(' ');
    }
    oitr = a.find('F');
    if (oitr->second == 1) {
        o.push('F');
    } else {
        o.push(' ');
    }
    oitr = a.find('D');
    if (oitr->second == 1) {
        o.push('D');
    } else {
        o.push(' ');
    }
    oitr = a.find('S');
    if (oitr->second == 1) {
        o.push('S');
    } else {
        o.push(' ');
    }
    oitr = a.find('A');
    if (oitr->second == 1) {
        o.push('A');
    } else {
        o.push(' ');
    }
    oitr = a.find('P');
    if (oitr->second == 1) {
        o.push('P');
    } else {
        o.push(' ');
    }
    oitr = a.find('O');
    if (oitr->second == 1) {
        o.push('O');
    } else {
        o.push(' ');
    }
    oitr = a.find('I');
    if (oitr->second == 1) {
        o.push('I');
    } else {
        o.push(' ');
    }
    oitr = a.find('U');
    if (oitr->second == 1) {
        o.push('U');
    } else {
        o.push(' ');
    }
    oitr = a.find('Y');
    if (oitr->second == 1) {
        o.push('Y');
    } else {
        o.push(' ');
    }
    oitr = a.find('T');
    if (oitr->second == 1) {
        o.push('T');
    } else {
        o.push(' ');
    }
    oitr = a.find('R');
    if (oitr->second == 1) {
        o.push('R');
    } else {
        o.push(' ');
    }
    oitr = a.find('E');
    if (oitr->second == 1) {
        o.push('E');
    } else {
        o.push(' ');
    }
    oitr = a.find('W');
    if (oitr->second == 1) {
        o.push('W');
    } else {
        o.push(' ');
    }
    oitr = a.find('Q');
    if (oitr->second == 1) {
        o.push('Q');
    } else {
        o.push(' ');
    }

    return o;
}

//All containers and variables
//Possible words to guess
list <string> Words = {"Abuse", "Adult", "Agent", "Anger", "Apple", "Award", "Basis", "Beach", "Birth", "Block", "Blood", "Board", "Brain", "Bread", "Break", "Brown", "Buyer",
    "Cause", "Chain", "Chair", "Chest", "Chief", "Child", "China", "Claim", "Class", "Clock", "Coach", "Coast", "Court", "Cover", "Cream", "Crime", "Cross", "Crowd",
    "Crown", "Cycle", "Dance", "Death", "Depth", "Doubt", "Draft", "Drama", "Dream", "Dress", "Drink", "Drive", "Earth", "Enemy", "Entry", "Error", "Event", "Faith",
    "Fault", "Field", "Fight", "Final", "Floor", "Focus", "Force", "Frame", "Frank", "Front", "Fruit", "Glass", "Grant", "Grass", "Green", "Group", "Guide", "Heart",
    "Henry", "Horse", "Hotel", "House", "Image", "Index", "Input", "Issue", "Japan", "Jones", "Judge", "Knife", "Laura", "Layer", "Level", "Lewis", "Light", "Limit",
    "Lunch", "Major", "March", "Match", "Metal", "Model", "Money", "Month", "Motor", "Mouth", "Music", "Night", "Noise", "North", "Novel", "Nurse", "Offer", "Order",
    "Other", "Owner", "Panel", "Paper", "Party", "Peace", "Peter", "Phase", "Phone", "Piece", "Pilot", "Pitch", "Place", "Plane", "Plant", "Plate", "Point", "Pound",
    "Power", "Press", "Price", "Pride", "Prize", "Proof", "Queen", "Radio", "Range", "Ratio", "Reply", "Right", "River", "Round", "Route", "Rugby", "Scale", "Scene",
    "Study", "Stuff", "Style", "Sugar", "Table", "Taste", "Terry", "Theme", "Thing", "Title", "Total", "Touch", "Tower", "Track", "Trade", "Train", "Trend", "Trial",
    "Trust", "Truth", "Uncle", "Union", "Unity", "Value", "Video", "Visit", "Voice", "Waste", "Watch", "Water", "While", "White", "Whole", "Woman", "World", "Youth",};
list <string> Words4 = {"able", "acid", "aged", "also", "area", "army", "away", "baby", "back", "ball", "band", "bank", "base", "bath", "bear", "beat", "been", "boat", "body", "bomb", "bond", "bone", "book", "boom", "born", "boss", "both", "bowl", "bulk", "burn", "bush", "busy", "call", "calm", "came", "camp", "card", "care", "case", "cash",
    "cast", "cell", "chat", "chip", "city", "club", "coal", "coat", "code", "cold", "come", "cook", "cool", "cope", "copy", "CORE", "cost", "crew", "crop", "dark", "data", "date", "dawn", "days", "dead", "deal", "dean", "dear", "debt", "deep", "deny", "desk",
    "dial", "dick", "diet", "disc", "disk", "does", "done", "door", "dose", "down", "draw", "drew", "drop", "drug", "dual", "duke", "dust", "duty", "each", "earn", "ease", "east", "easy", "edge", "else", "even", "ever", "evil", "exit", "face", "fact", "fail",
    "fair", "fall", "farm", "fast", "fate", "fear", "feed", "feel", "feet", "fell", "felt", "file", "fill", "film", "find", "fine", "fire", "firm", "fish", "five", "flat", "flow", "food", "foot", "ford", "form", "fort", "four", "free", "from", "fuel", "full",
    "fund", "gain", "game", "gate", "gave", "gear", "gene", "gift", "girl", "give", "glad", "goal", "goes", "gold", "Golf", "gone", "good", "gray", "grew", "grey", "grow", "gulf", "hair", "half", "hall", "hand", "hang", "hard", "harm", "hate", "have", "head",
    "hear", "heat", "held", "hell", "help", "here", "hero", "high", "hill", "hire", "hold", "hole", "holy", "home", "hope", "host", "hour", "huge", "hung", "hunt", "hurt", "idea", "inch", "into", "iron", "item", "jack", "jane", "jean", "john", "join", "jump",
    "jury", "just", "keen", "keep", "kent", "kept", "kick", "kill", "kind", "king", "knee", "knew", "know", "lack", "lady", "laid", "lake", "land", "lane", "last", "late", "lead", "left", "less", "life", "lift", "like", "line", "link", "list", "live", "load",
    "loan", "lock", "logo", "long", "look", "lord", "lose", "loss", "lost", "love", "luck", "made", "mail", "main", "make", "male", "many", "Mark", "mass", "matt", "meal", "mean", "meat", "meet", "menu", "mere", "mike", "mile", "milk", "mill", "mind", "mine",
    "miss", "mode", "mood", "moon", "more", "most", "move", "much", "must", "name", "navy", "near", "neck", "need", "news", "next", "nice", "nick", "nine", "none", "nose", "note", "okay", "once", "only", "onto", "open", "oral", "over", "pace", "pack", "page",
    "paid", "pain", "pair", "palm", "park", "part", "pass", "past", "path", "peak", "pick", "pink", "pipe", "plan", "play", "plot", "plug", "plus", "poll", "pool", "poor", "port", "post", "pull", "pure", "push", "race", "rail", "rain", "rank", "rare", "rate",
    "read", "real", "rear", "rely", "rent", "rest", "rice", "rich", "ride", "ring", "rise", "risk", "road", "rock", "role", "roll", "roof", "room", "root", "rose", "rule", "rush", "ruth", "safe", "said", "sake", "sale", "salt", "same", "sand", "save", "seat",
    "seed", "seek", "seem", "seen", "self", "sell", "send", "sent", "sept", "ship", "shop", "shot", "show", "shut", "sick", "side", "sign", "site", "size", "skin", "slip", "slow", "snow", "soft", "soil", "sold", "sole", "some", "song", "soon", "sort", "soul",
    "spot", "star", "stay", "step", "stop", "such", "suit", "sure", "take", "tale", "talk", "tall", "tank", "tape", "task", "team", "tech", "tell", "tend", "term", "test", "text", "than", "that", "them", "then", "they", "thin", "this", "thus", "till", "time",
    "tiny", "told", "toll", "tone", "tony", "took", "tool", "tour", "town", "tree", "trip", "TRUE", "tune", "turn", "twin", "type", "unit", "upon", "used", "user", "vary", "vast", "very", "vice", "view", "vote", "wage", "wait", "wake", "walk", "wall", "want",
    "ward", "warm", "wash", "wave", "ways", "weak", "wear", "week", "well", "went", "were", "west", "what", "when", "whom", "wide", "wife", "wild", "will", "wind", "wine", "wing", "wire", "wise", "wish", "with", "wood", "word", "wore", "work", "yard", "yeah",
    "year", "your", "zero", "zone"};
list <string> Words6 = {"appeal", "appear", "around", "arrive", "artist", "aspect", "assess", "assist", "assume", "attack", "attend", "august", "author", "avenue", "backed", "barely", "battle", "beauty", "became", "become", "before", "behalf", "behind", "belief", "belong",
    "berlin", "better", "beyond", "bishop", "border", "bottle", "bottom", "bought", "branch", "breath", "bridge", "bright", "broken", "budget", "burden", "bureau", "button", "camera", "cancer", "cannot", "carbon", "career", "castle", "casual", "caught", "center", "centre", "chance", "change", "charge", "choice", "choose",
    "chosen", "church", "circle", "client", "closed", "closer", "coffee", "column", "combat", "coming", "common", "comply", "copper", "corner", "costly", "county", "couple", "course", "covers", "create", "credit", "crisis", "custom", "damage", "danger", "dealer", "debate", "decade", "decide", "defeat", "defend", "define",
    "degree", "demand", "depend", "deputy", "desert", "design", "desire", "detail", "detect", "device", "differ", "dinner", "direct", "doctor", "dollar", "domain", "double", "driven", "driver", "during", "easily", "eating", "editor", "effect", "effort", "eighth", "either", "eleven", "emerge", "empire", "employ", "enable",
    "ending", "energy", "engage", "engine", "enough", "ensure", "entire", "entity", "equity", "escape", "estate", "ethnic", "exceed", "except", "excess", "expand", "expect", "expert", "export", "extend", "extent", "fabric", "facing", "factor", "failed", "fairly", "fallen", "family", "famous", "father", "fellow", "female",
    "figure", "filing", "finger", "finish", "fiscal", "flight", "flying", "follow", "forced", "forest", "forget", "formal", "format", "former", "foster", "fought", "fourth", "French", "friend", "future", "garden", "gather", "gender", "german", "global", "golden", "ground", "growth", "guilty", "handed", "handle", "happen",
    "hardly", "headed", "health", "height", "hidden", "holder", "honest", "impact", "import", "income", "indeed", "injury", "inside", "intend", "intent", "invest", "island", "itself", "jersey", "joseph", "junior", "killed", "labour", "latest", "latter", "launch", "lawyer", "leader", "league", "leaves", "legacy", "length",
    "lesson", "letter", "lights", "likely", "linked", "liquid", "listen", "little", "living", "losing", "lucent", "luxury", "mainly", "making", "manage", "manner", "manual", "margin", "marine", "marked", "market", "martin", "master", "matter", "mature", "medium", "member", "memory", "mental", "merely", "merger", "method",
    "middle", "miller", "mining", "minute", "mirror", "mobile", "modern", "modest", "module", "moment", "morris", "mostly", "mother", "motion", "moving", "murder", "museum", "mutual", "myself", "narrow", "nation", "native", "nature", "nearby", "nearly", "nights", "nobody", "normal", "notice", "notion", "number", "object",
    "obtain", "office", "offset", "online", "option", "orange", "origin", "output", "oxford", "packed", "palace", "parent", "partly", "patent", "people", "period", "permit", "person", "phrase", "picked", "planet", "player", "please", "plenty", "pocket", "police", "policy", "prefer", "pretty", "prince", "prison", "profit",
    "proper", "proven", "public", "pursue", "raised", "random", "rarely", "rather", "rating", "reader", "really", "reason", "recall", "recent", "record", "reduce", "reform", "regard", "regime", "region", "relate", "relief", "remain", "remote", "remove", "repair", "repeat", "replay", "report", "rescue", "resort", "result",
    "retail", "retain", "return", "reveal", "review", "reward", "riding", "rising", "robust", "ruling", "safety", "salary", "sample", "saving", "saying", "scheme", "school", "screen", "search", "season", "second", "secret", "sector", "secure", "seeing", "select", "seller", "senior", "series", "server", "settle", "severe",
    "sexual", "should", "signal", "signed", "silent", "silver", "simple", "simply", "single", "sister", "slight", "smooth", "social", "solely", "sought", "source", "soviet", "speech", "spirit", "spoken", "spread", "spring", "square", "stable", "status", "steady", "stolen", "strain", "stream", "street", "stress", "strict",
    "strike", "string", "strong", "struck", "studio", "submit", "sudden", "suffer", "summer", "summit", "supply", "surely", "survey", "switch", "symbol", "system", "taking", "talent", "target", "taught", "tenant", "tender", "tennis", "thanks", "theory", "thirty", "though", "threat", "thrown", "ticket", "timely", "timing",
    "tissue", "toward", "travel", "treaty", "trying", "twelve", "twenty", "unable", "unique", "united", "unless", "unlike", "update", "useful", "valley", "varied", "vendor", "versus", "victim", "vision", "visual", "volume", "walker", "wealth", "weekly", "weight", "wholly", "window", "winner", "winter", "within", "wonder",
    "worker", "wright", "writer", "yellow"};
//Word that is being entered by player
multimap<int, char>theGuess;
//Letters to be played during the game
map<char, int> alphabet = {
    {'A', 1},
    {'B', 1},
    {'C', 1},
    {'D', 1},
    {'E', 1},
    {'F', 1},
    {'G', 1},
    {'H', 1},
    {'I', 1},
    {'J', 1},
    {'K', 1},
    {'L', 1},
    {'M', 1},
    {'N', 1},
    {'O', 1},
    {'P', 1},
    {'Q', 1},
    {'R', 1},
    {'S', 1},
    {'T', 1},
    {'U', 1},
    {'V', 1},
    {'W', 1},
    {'X', 1},
    {'Y', 1},
    {'Z', 1}
};
map<char, int> alphabetswap = {
    {'A', 1},
    {'B', 1},
    {'C', 1},
    {'D', 1},
    {'E', 1},
    {'F', 1},
    {'G', 1},
    {'H', 1},
    {'I', 1},
    {'J', 1},
    {'K', 1},
    {'L', 1},
    {'M', 1},
    {'N', 1},
    {'O', 1},
    {'P', 1},
    {'Q', 1},
    {'R', 1},
    {'S', 1},
    {'T', 1},
    {'U', 1},
    {'V', 1},
    {'W', 1},
    {'X', 1},
    {'Y', 1},
    {'Z', 1}
};
//Ordered letters to display the keyboard
stack<char> orderedLetters;
//Letters to display the keyboard
queue<char> preorderedLetters;
//Letters that have been guessed correctly
set<char> letters;
set<char> letterswap;

int selection = 0;

int main() { //Start of program
    cout << "\tWelcome to my recreation of the game Wordle!\n\n";
    do {

        cout << "\tWhat would you like to do?\n\t1. Guess a 5-letter word\tNORMAL\n\t2. Guess a 4-letter word\tEASY\n\t3. Guess a 6-letter word\tHARD\n\t4. Tutorial\n\t5. Exit\n";
        cin >> selection;
        switch (selection) 
        {
            {
            
            case 1:
            {
                //Declaring the variable that holds the guessed value
                int attempts = 0;
                string attempt = "";
                string Word;
                map<char,int> :: iterator asitr;
                for (auto asitr = alphabetswap.begin(); asitr != alphabetswap.end(); ++asitr) 
                {
                    asitr->second = 1;
                }
                alphabet.swap(alphabetswap);
                
                set<char> :: iterator ssitr;
                for (auto ssitr = letterswap.begin(); ssitr != letterswap.end(); ++ssitr) 
                {
                    letterswap.erase(ssitr);
                }
                letters.swap(letterswap);
                while (attempts < 6) {
                    //Start of the game
                    //Sorting the list of words
                    Words.sort();

                    //Randomly generating a 5-letter word from the List of words
                    if (attempts < 1) {
                        cout << "A random 5-letter word has been generated..." << endl;
                        Word = randomWord(Words, attempts);
                    }

                    //Calling the lowerUpper function on generated word
                    Word = lowerUpper(Word);

                    //Displaying the available letters and available letters
                    displayLetters(alphabet, letters, attempts, orderedLetters);

                    //Displaying menu for entering a value
                    cout << "Enter a five letter word:\n\t";

                    //Store the Progress
                    theGuess = storeProgress(theGuess, Word, attempt);
                    //Output the progress
                    displayProgress(theGuess, Word, attempt);

                    cin >> attempt;

                    //Calling lowerUpper function on the users entered word
                    attempt = lowerUpper(attempt);

                    //Making sure player enters a five letter word 
                    while (attempt.size() != 5) {
                        cout << "Please enter a word that is five letters:" << endl;
                        displayProgress(theGuess, Word, attempt);
                        cin >> attempt;
                        attempt = lowerUpper(attempt);
                    }

                    //Checking to see if the letters have already been used
                    map<char, int>::iterator aitr;
                    for (int count = 0; count < 5; count++) {
                        aitr = alphabet.find(attempt[count]);
                        if (aitr->second == 0) {
                            cout << "The letter '" << attempt[count] << "' has already been ruled out, enter another five-letter word:" << endl;
                            displayProgress(theGuess, Word, attempt);
                            cin >> attempt;
                            attempt = lowerUpper(attempt);
                        }
                    }

                    //Making all values that have already been chosen, and that are not in the word unusable
                    for (int count = 0; count < 5; count++) {
                        int findNum = Word.find(attempt[count]);
                        if (findNum == -1) {
                            aitr = alphabet.find(attempt[count]);
                            aitr->second = 0;
                        } else {
                            letters.insert(attempt[count]);
                        }

                    }

                    //Clearing stack and queue
                    preorderedLetters = clearQueue(preorderedLetters);
                    orderedLetters = clearStack(orderedLetters);
                    //Ordering alphabet into keyboard display
                    preorderedLetters = gatherKeyboard(preorderedLetters, alphabet);
                    orderedLetters = swapKeyboard(preorderedLetters, orderedLetters);

                    //Win condition
                    if (attempt == Word) {
                        attempt = upperLower(attempt);
                        cout << "\n\nCongratulations, " << attempt << " is the correct word!" << endl;
                        selection = 0;
                        break;
                    }

                    attempts++;
                    cout << "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";

                }
                if (attempts == 6) {
                    cout << "You have guessed too many times, sorry!" << endl;
                    cout << "The correct word was: " << Word << endl;
                    selection = 0;
                    break;
                }
                break;
            }
            case 2:
            {
                //Declaring the variable that holds the guessed value
                int attempts4 = 0;
                string attempt4 = "";
                string Word4;

                for (auto asitr = alphabetswap.begin(); asitr != alphabetswap.end(); ++asitr) 
                {
                    asitr->second = 1;
                }
                alphabet.swap(alphabetswap);
                for (auto ssitr = letterswap.begin(); ssitr != letterswap.end(); ++ssitr) 
                {
                    letterswap.erase(ssitr);
                }
                letters.swap(letterswap);
                while (attempts4 < 6) {
                    //Start of the game
                    //Sorting the list of words
                    Words4.sort();
                    //Randomly generating a 4-letter word from the List of words
                    if (attempts4 < 1) {
                        cout << "A random 4-letter word has been generated..." << endl;
                        Word4 = randomWord(Words4, attempts4);
                    }

                    //Calling the lowerUpper function on generated word
                    Word4 = lowerUpper4(Word4);

                    //Displaying the available letters and correct letters
                    displayLetters(alphabet, letters, attempts4, orderedLetters);


                    //Displaying menu for entering a value
                    cout << "Enter a four letter word:\n\t";

                    //Store the Progress
                    theGuess = storeProgress4(theGuess, Word4, attempt4);
                    //Output the progress
                    displayProgress4(theGuess, Word4, attempt4);

                    cin >> attempt4;

                    //Calling lowerUpper function on the users entered word
                    attempt4 = lowerUpper4(attempt4);

                    //Making sure player enters a five letter word 
                    while (attempt4.size() != 4) {
                        cout << "Please enter a word that is four letters:" << endl;
                        displayProgress4(theGuess, Word4, attempt4);
                        cin >> attempt4;
                        attempt4 = lowerUpper4(attempt4);
                    }

                    //Checking to see if the letters have already been used
                    map<char, int>::iterator aitr;
                    for (int count = 0; count < 4; count++) {
                        aitr = alphabet.find(attempt4[count]);
                        if (aitr->second == 0) {
                            cout << "The letter '" << attempt4[count] << "' has already been ruled out, enter another four-letter word:" << endl;
                            displayProgress4(theGuess, Word4, attempt4);
                            cin >> attempt4;
                            attempt4 = lowerUpper4(attempt4);
                        }
                    }

                    //Making all values that have already been chosen, and that are not in the word unusable
                    for (int count = 0; count < 4; count++) {
                        int findNum = Word4.find(attempt4[count]);
                        if (findNum == -1) {
                            aitr = alphabet.find(attempt4[count]);
                            aitr->second = 0;
                        } else {
                            letters.insert(attempt4[count]);
                        }

                    }

                    //Clearing stack and queue
                    preorderedLetters = clearQueue(preorderedLetters);
                    orderedLetters = clearStack(orderedLetters);
                    //Ordering alphabet into keyboard display
                    preorderedLetters = gatherKeyboard(preorderedLetters, alphabet);
                    orderedLetters = swapKeyboard(preorderedLetters, orderedLetters);

                    //Win condition
                    if (attempt4 == Word4) {
                        attempt4 = upperLower(attempt4);
                        cout << "\n\nCongratulations, " << attempt4 << " is the correct word!" << endl;
                        break;
                    }

                    attempts4++;
                    cout << "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";

                }
                if (attempts4 == 6) {
                    cout << "You have guessed too many times, sorry!" << endl;
                    cout << "The correct word was: " << Word4 << endl;
                    break;
                }
                break;
            }
            case 3:
            {
                //Declaring the variable that holds the guessed value
                int attempts6 = 0;
                string attempt6 = " ";
                string Word6;

                for (auto asitr = alphabetswap.begin(); asitr != alphabetswap.end(); ++asitr) 
                {
                    asitr->second = 1;
                }
                alphabet.swap(alphabetswap);
                for (auto ssitr = letterswap.begin(); ssitr != letterswap.end(); ++ssitr) 
                {
                    letterswap.erase(ssitr);
                }
                letters.swap(letterswap);
                
                while (attempts6 < 6) {
                    //Start of the game
                    //Sorting the list of words
                    Words6.sort();
                    //Randomly generating a 6-letter word from the List of words
                    if (attempts6 < 1) {
                        cout << "A random 6-letter word has been generated..." << endl;
                        Word6 = randomWord(Words6, attempts6);
                    }

                    //Calling the lowerUpper function on generated word
                    Word6 = lowerUpper6(Word6);

                    //Displaying the available letters and correct letters
                    displayLetters(alphabet, letters, attempts6, orderedLetters);


                    //Displaying menu for entering a value
                    cout << "Enter a six letter word:\n\t";

                    //Store the Progress
                    theGuess = storeProgress6(theGuess, Word6, attempt6);
                    //Output the progress
                    displayProgress6(theGuess, Word6, attempt6);

                    cin >> attempt6;

                    //Calling lowerUpper function on the users entered word
                    attempt6 = lowerUpper6(attempt6);

                    //Making sure player enters a five letter word 
                    while (attempt6.size() != 6) {
                        cout << "Please enter a word that is six letters:" << endl;
                        displayProgress6(theGuess, Word6, attempt6);
                        cin >> attempt6;
                        attempt6 = lowerUpper6(attempt6);
                    }

                    //Checking to see if the letters have already been used
                    map<char, int>::iterator aitr;
                    for (int count = 0; count < 6; count++) {
                        aitr = alphabet.find(attempt6[count]);
                        if (aitr->second == 0) {
                            cout << "The letter '" << attempt6[count] << "' has already been ruled out, enter another six-letter word:" << endl;
                            displayProgress6(theGuess, Word6, attempt6);
                            cin >> attempt6;
                            attempt6 = lowerUpper6(attempt6);
                        }
                    }

                    //Making all values that have already been chosen, and that are not in the word unusable
                    for (int count = 0; count < 6; count++) {
                        int findNum = Word6.find(attempt6[count]);
                        if (findNum == -1) {
                            aitr = alphabet.find(attempt6[count]);
                            aitr->second = 0;
                        } else {
                            letters.insert(attempt6[count]);
                        }

                    }

                    //Clearing stack and queue
                    preorderedLetters = clearQueue(preorderedLetters);
                    orderedLetters = clearStack(orderedLetters);
                    //Ordering alphabet into keyboard display
                    preorderedLetters = gatherKeyboard(preorderedLetters, alphabet);
                    orderedLetters = swapKeyboard(preorderedLetters, orderedLetters);

                    //Win condition
                    if (attempt6 == Word6) {
                        attempt6 = upperLower(attempt6);
                        cout << "\n\nCongratulations, " << attempt6 << " is the correct word!" << endl;
                        break;
                    }

                    attempts6++;
                    cout << "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";

                }
                if (attempts6 == 6) {
                    cout << "You have guessed too many times, sorry!" << endl;
                    cout << "The correct word was: " << Word6 << endl << endl << endl;
                    break;
                }
            }
                break;
            case 4:
                cout << "\n\n\tThe rules of the game are simple:" << endl <<
                        "\t\t1. Choose the version of the game you would like to play." << endl <<
                        "\t\t\ta. Guess a 4 letter word\tEASY\n\t\t\tb. Guess a 5 letter word\tINTERMEDIATE\n\t\t\tc. Guess a 6 letter word\tHARD\n" <<
                        "\t\t2. A random word of the word size you chose will be generated. You only have 6 tries to guess it" <<
                        "\n\t\t3. When you incorrectly guess a letter, it will be removed from the LIST OF AVAILABLE LETTERS\n" <<
                        "\t\t4. If you guess a letter correctly, but not in the right location, it will appear in the LIST OF CORRECT LETTERS\n" <<
                        "\t\t5. If you guess the letters location, it will appear in the selection bar\n" <<
                        "\t\t6. All letters that haven't been guessed will be displayed as '_'" << endl <<
                        "\t\tGet Guessing!\n\n\n";
                break;
            case 5:
                cout << "\n\n\tThank you for playing!";
                break;
        }
        }
    } while (selection != 5);
    return 0;
}
